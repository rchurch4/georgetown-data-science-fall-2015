Brief descriptions of files and directories included in project2 deliverable, from team droptable. 

/analysis
- code for all project2 analyses
- code for combining, cleaning, and saving data as Rdata files. source data
  for this was not included due to its size, but can be viewed on the
  github repository:
  https://github.com/rchurch4/georgetown-data-science-fall-2015/tree/master/data

/data
- one data set for each website (Rdata format)
- data for Yelp logistic regression ROC curve (Rdata format)
- network analyses use CSV input data which are not included, but are derived from 
  the above Rdata files. code for deriving this is in analysis/read_clean_data

/writeup
- contains the writeup in word format